
import streamlit as st
from datetime import datetime

st.set_page_config(page_title="Fursah-X Control Panel", layout="wide")

st.title("🧠 لوحة تحكم Fursah-X")
st.subheader("رحلة المليار • الذكاء الاستثماري")

col1, col2, col3 = st.columns(3)
col1.metric("📈 إجمالي الأرباح", "SAR 18,400", "+8.2% اليوم")
col2.metric("🎯 عدد الفرص المنفذة", "352", "+12")
col3.metric("🚀 تقدم رحلة المليار", "1.84%", "مستمر ✅")

st.divider()
st.header("📊 المحفظة الذكية")
st.success("الرصيد الحالي: 18,400 ريال سعودي")

if st.button("🔁 سحب الأرباح الآن"):
    st.info("✅ تم طلب التحويل إلى حساب الراجحي.")

st.divider()
st.header("📅 نشاط اليوم")
st.write("- عدد الفرص الجديدة: 18")
st.write("- أفضل فرصة اليوم: VocalMint.io ✅")
st.write("- حالة التشغيل: فعّال ومستقر")

st.divider()
st.caption("منصة Fursah-X • الجيل القادم من التشغيل الذكي • جميع الحقوق محفوظة © 2025")
