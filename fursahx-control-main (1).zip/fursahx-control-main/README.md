# fursahx-control
لوحة التحكم الذكية لمنصة Fursah-X – نسخة مؤقتة لتجربة التشغيل
